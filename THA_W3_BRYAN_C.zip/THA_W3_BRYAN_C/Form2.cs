﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace THA_W3_BRYAN_THx
{
    public partial class SecondForm : Form
    {
        public MainForm form1;
        public string LabelZero

        {
            get
            {
                return this.label_zero.Text;
            }
            set
            {
                this.label_zero.Text = value;
            }
        }
        public SecondForm()
        {
            InitializeComponent();
        }

        private void SecondForm_Load(object sender, EventArgs e)
        {

        }

        private void CB_ToA_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBOXTOA.Checked && CheckBoxTrue1.Checked)
            {
                Btn_Magic.Enabled = true;
            }
            else
            {
                Btn_Magic.Enabled = false;

            }
        }

        private void Btn_Magic_Click(object sender, EventArgs e)
        {

            if (TurqoiseBG.Checked || BlueBG.Checked ||
                PurpleBG.Checked || RedBG.Checked || YellowBG.Checked)
            { 
                if (RB_AquaText.Checked || GreenText.Checked || PinkText.Checked)
                {
                    if (TurqoiseBG.Checked)
                    {
                        MainForm.formInstance.BackColor = Color.Turquoise;
                    }
                    else if (BlueBG.Checked)
                    {
                        MainForm.formInstance.BackColor = Color.Blue;
                    }
                    else if (YellowBG.Checked)
                    {
                        MainForm.formInstance.BackColor = Color.DarkKhaki;
                    }
                    else if (RedBG.Checked)
                    {
                        MainForm.formInstance.BackColor = Color.DarkRed;

                    }
                    else if (PurpleBG.Checked)
                    {
                        MainForm.formInstance.BackColor = Color.Purple;
                    }
                    if (GreenText.Checked)
                    {
                        MainForm.formInstance.ForeColor = Color.LightGreen;
                    }
                    else if (PinkText.Checked)
                    {
                        MainForm.formInstance.ForeColor = Color.Pink;
                    }
                    else if (RB_AquaText.Checked)
                    {
                        MainForm.formInstance.ForeColor = Color.Aqua;
                    }
                }
                else
                {
                    MessageBox.Show("Please select color correctly!!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Please select color correctly!!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void label_Hi_Click(object sender, EventArgs e)
        {

        }

        private void CB_True2_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBOXTOA.Checked && CheckBoxTrue1.Checked)
            {
                Btn_Magic.Enabled = true;
            }
            else
            {
                Btn_Magic.Enabled = false;
                
            }
        }
    }
}
