﻿namespace THA_W3_BRYAN_THx
{
    partial class SecondForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_bgcolor = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PurpleBG = new System.Windows.Forms.RadioButton();
            this.TurqoiseBG = new System.Windows.Forms.RadioButton();
            this.YellowBG = new System.Windows.Forms.RadioButton();
            this.BlueBG = new System.Windows.Forms.RadioButton();
            this.RedBG = new System.Windows.Forms.RadioButton();
            this.label_textcolor = new System.Windows.Forms.Label();
            this.RB_AquaText = new System.Windows.Forms.RadioButton();
            this.PinkText = new System.Windows.Forms.RadioButton();
            this.GreenText = new System.Windows.Forms.RadioButton();
            this.CheckBOXTOA = new System.Windows.Forms.CheckBox();
            this.CheckBoxTrue1 = new System.Windows.Forms.CheckBox();
            this.Btn_Magic = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.label_zero = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_bgcolor
            // 
            this.label_bgcolor.AutoSize = true;
            this.label_bgcolor.Location = new System.Drawing.Point(32, 63);
            this.label_bgcolor.Name = "label_bgcolor";
            this.label_bgcolor.Size = new System.Drawing.Size(220, 16);
            this.label_bgcolor.TabIndex = 0;
            this.label_bgcolor.Text = "Pick your favorite background color:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.PurpleBG);
            this.panel1.Controls.Add(this.TurqoiseBG);
            this.panel1.Controls.Add(this.YellowBG);
            this.panel1.Controls.Add(this.BlueBG);
            this.panel1.Controls.Add(this.RedBG);
            this.panel1.Location = new System.Drawing.Point(35, 91);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 142);
            this.panel1.TabIndex = 1;
            // 
            // PurpleBG
            // 
            this.PurpleBG.AutoSize = true;
            this.PurpleBG.Location = new System.Drawing.Point(0, 102);
            this.PurpleBG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PurpleBG.Name = "PurpleBG";
            this.PurpleBG.Size = new System.Drawing.Size(67, 20);
            this.PurpleBG.TabIndex = 4;
            this.PurpleBG.Text = "Purple";
            this.PurpleBG.UseVisualStyleBackColor = true;
            // 
            // TurqoiseBG
            // 
            this.TurqoiseBG.AutoSize = true;
            this.TurqoiseBG.Location = new System.Drawing.Point(0, 78);
            this.TurqoiseBG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TurqoiseBG.Name = "TurqoiseBG";
            this.TurqoiseBG.Size = new System.Drawing.Size(89, 20);
            this.TurqoiseBG.TabIndex = 3;
            this.TurqoiseBG.Text = "Turquoise";
            this.TurqoiseBG.UseVisualStyleBackColor = true;
            // 
            // YellowBG
            // 
            this.YellowBG.AutoSize = true;
            this.YellowBG.Location = new System.Drawing.Point(0, 53);
            this.YellowBG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.YellowBG.Name = "YellowBG";
            this.YellowBG.Size = new System.Drawing.Size(68, 20);
            this.YellowBG.TabIndex = 2;
            this.YellowBG.Text = "Yellow";
            this.YellowBG.UseVisualStyleBackColor = true;
            // 
            // BlueBG
            // 
            this.BlueBG.AutoSize = true;
            this.BlueBG.Location = new System.Drawing.Point(0, 28);
            this.BlueBG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BlueBG.Name = "BlueBG";
            this.BlueBG.Size = new System.Drawing.Size(55, 20);
            this.BlueBG.TabIndex = 1;
            this.BlueBG.Text = "Blue";
            this.BlueBG.UseVisualStyleBackColor = true;
            // 
            // RedBG
            // 
            this.RedBG.AutoSize = true;
            this.RedBG.Location = new System.Drawing.Point(0, 3);
            this.RedBG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RedBG.Name = "RedBG";
            this.RedBG.Size = new System.Drawing.Size(54, 20);
            this.RedBG.TabIndex = 0;
            this.RedBG.Text = "Red";
            this.RedBG.UseVisualStyleBackColor = true;
            // 
            // label_textcolor
            // 
            this.label_textcolor.AutoSize = true;
            this.label_textcolor.Location = new System.Drawing.Point(281, 91);
            this.label_textcolor.Name = "label_textcolor";
            this.label_textcolor.Size = new System.Drawing.Size(92, 16);
            this.label_textcolor.TabIndex = 2;
            this.label_textcolor.Text = "Pick text color:";
            // 
            // RB_AquaText
            // 
            this.RB_AquaText.AutoSize = true;
            this.RB_AquaText.Location = new System.Drawing.Point(285, 120);
            this.RB_AquaText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RB_AquaText.Name = "RB_AquaText";
            this.RB_AquaText.Size = new System.Drawing.Size(60, 20);
            this.RB_AquaText.TabIndex = 3;
            this.RB_AquaText.Text = "Aqua";
            this.RB_AquaText.UseVisualStyleBackColor = true;
            // 
            // PinkText
            // 
            this.PinkText.AutoSize = true;
            this.PinkText.Location = new System.Drawing.Point(285, 145);
            this.PinkText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PinkText.Name = "PinkText";
            this.PinkText.Size = new System.Drawing.Size(54, 20);
            this.PinkText.TabIndex = 4;
            this.PinkText.Text = "Pink";
            this.PinkText.UseVisualStyleBackColor = true;
            // 
            // GreenText
            // 
            this.GreenText.AutoSize = true;
            this.GreenText.Location = new System.Drawing.Point(285, 169);
            this.GreenText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GreenText.Name = "GreenText";
            this.GreenText.Size = new System.Drawing.Size(65, 20);
            this.GreenText.TabIndex = 5;
            this.GreenText.Text = "Green";
            this.GreenText.UseVisualStyleBackColor = true;
            // 
            // CheckBOXTOA
            // 
            this.CheckBOXTOA.AutoSize = true;
            this.CheckBOXTOA.Location = new System.Drawing.Point(35, 238);
            this.CheckBOXTOA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CheckBOXTOA.Name = "CheckBOXTOA";
            this.CheckBOXTOA.Size = new System.Drawing.Size(231, 20);
            this.CheckBOXTOA.TabIndex = 6;
            this.CheckBOXTOA.Text = "I agree to the Terms of Agreement";
            this.CheckBOXTOA.UseVisualStyleBackColor = true;
            this.CheckBOXTOA.CheckedChanged += new System.EventHandler(this.CB_ToA_CheckedChanged);
            // 
            // CheckBoxTrue1
            // 
            this.CheckBoxTrue1.AutoSize = true;
            this.CheckBoxTrue1.Location = new System.Drawing.Point(35, 262);
            this.CheckBoxTrue1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CheckBoxTrue1.Name = "CheckBoxTrue1";
            this.CheckBoxTrue1.Size = new System.Drawing.Size(232, 20);
            this.CheckBoxTrue1.TabIndex = 7;
            this.CheckBoxTrue1.Text = "All the choice I pick above are true";
            this.CheckBoxTrue1.UseVisualStyleBackColor = true;
            this.CheckBoxTrue1.CheckedChanged += new System.EventHandler(this.CB_True2_CheckedChanged);
            // 
            // Btn_Magic
            // 
            this.Btn_Magic.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Magic.Enabled = false;
            this.Btn_Magic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Magic.Location = new System.Drawing.Point(326, 233);
            this.Btn_Magic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Btn_Magic.Name = "Btn_Magic";
            this.Btn_Magic.Size = new System.Drawing.Size(106, 28);
            this.Btn_Magic.TabIndex = 8;
            this.Btn_Magic.Text = "MAGIC";
            this.Btn_Magic.UseVisualStyleBackColor = false;
            this.Btn_Magic.Click += new System.EventHandler(this.Btn_Magic_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // label_zero
            // 
            this.label_zero.AutoSize = true;
            this.label_zero.Location = new System.Drawing.Point(32, 26);
            this.label_zero.Name = "label_zero";
            this.label_zero.Size = new System.Drawing.Size(0, 16);
            this.label_zero.TabIndex = 9;
            this.label_zero.Click += new System.EventHandler(this.label_Hi_Click);
            // 
            // SecondForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.label_zero);
            this.Controls.Add(this.Btn_Magic);
            this.Controls.Add(this.CheckBoxTrue1);
            this.Controls.Add(this.CheckBOXTOA);
            this.Controls.Add(this.GreenText);
            this.Controls.Add(this.PinkText);
            this.Controls.Add(this.RB_AquaText);
            this.Controls.Add(this.label_textcolor);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label_bgcolor);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "SecondForm";
            this.Text = "Second Window Form";
            this.Load += new System.EventHandler(this.SecondForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_bgcolor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton PurpleBG;
        private System.Windows.Forms.RadioButton TurqoiseBG;
        private System.Windows.Forms.RadioButton YellowBG;
        private System.Windows.Forms.RadioButton BlueBG;
        private System.Windows.Forms.RadioButton RedBG;
        private System.Windows.Forms.Label label_textcolor;
        private System.Windows.Forms.RadioButton RB_AquaText;
        private System.Windows.Forms.RadioButton PinkText;
        private System.Windows.Forms.RadioButton GreenText;
        private System.Windows.Forms.CheckBox CheckBOXTOA;
        private System.Windows.Forms.CheckBox CheckBoxTrue1;
        private System.Windows.Forms.Button Btn_Magic;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label_zero;
    }
}