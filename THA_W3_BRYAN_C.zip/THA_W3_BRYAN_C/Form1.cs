﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace THA_W3_BRYAN_THx
{
    public partial class MainForm : Form
    {
        public static MainForm formInstance;
        public TextBox tbx;

        SecondForm form2 = new SecondForm();
        int checks = 0;

        public MainForm()
        {
            InitializeComponent();
            formInstance = this;
            tbx = TextBox_Name;
        }

        private void Btn_NextForm_Click(object sender, EventArgs e)
        {
            form2.Show();
            checks = 1;
            if (CheckBoxTrue.Checked && checks > 0)
            {
                ButtonSubmit.Enabled = true;
            }
            else
            {
                ButtonSubmit.Enabled = false;
            }
        }

        private void Btn_Submit1_Click(object sender, EventArgs e)
        {
            
                if (string.IsNullOrEmpty(TextBox_Name.Text) || string.IsNullOrEmpty(TextBox_Artist.Text))
                {
                    MessageBox.Show("Please don't leave the textbox empty!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    form2.LabelZero = "Hi my name is " + TextBox_Name.Text + ", and my favorite artist is " + TextBox_Artist.Text + ".";
                }
            
            
        }
            

 
        private void CB_True1_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBoxTrue.Checked && checks > 0)
            {
                ButtonSubmit.Enabled = true;
            }
            else
            {
                ButtonSubmit.Enabled = false;
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
