﻿namespace THA_W3_BRYAN_THx
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonNextForm = new System.Windows.Forms.Button();
            this.label_Name = new System.Windows.Forms.Label();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.label_Artist = new System.Windows.Forms.Label();
            this.TextBox_Artist = new System.Windows.Forms.TextBox();
            this.CheckBoxTrue = new System.Windows.Forms.CheckBox();
            this.ButtonSubmit = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.SuspendLayout();
            // 
            // ButtonNextForm
            // 
            this.ButtonNextForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.ButtonNextForm.Location = new System.Drawing.Point(37, 200);
            this.ButtonNextForm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ButtonNextForm.Name = "ButtonNextForm";
            this.ButtonNextForm.Size = new System.Drawing.Size(183, 41);
            this.ButtonNextForm.TabIndex = 0;
            this.ButtonNextForm.Text = "Open Next Form";
            this.ButtonNextForm.UseVisualStyleBackColor = true;
            this.ButtonNextForm.Click += new System.EventHandler(this.Btn_NextForm_Click);
            // 
            // label_Name
            // 
            this.label_Name.AutoSize = true;
            this.label_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label_Name.Location = new System.Drawing.Point(34, 40);
            this.label_Name.Name = "label_Name";
            this.label_Name.Size = new System.Drawing.Size(45, 17);
            this.label_Name.TabIndex = 1;
            this.label_Name.Text = "Name";
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.TextBox_Name.Location = new System.Drawing.Point(108, 34);
            this.TextBox_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(184, 23);
            this.TextBox_Name.TabIndex = 2;
            // 
            // label_Artist
            // 
            this.label_Artist.AutoSize = true;
            this.label_Artist.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label_Artist.Location = new System.Drawing.Point(34, 84);
            this.label_Artist.Name = "label_Artist";
            this.label_Artist.Size = new System.Drawing.Size(117, 17);
            this.label_Artist.TabIndex = 3;
            this.label_Artist.Text = "My Favorite Artist";
            // 
            // TextBox_Artist
            // 
            this.TextBox_Artist.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.TextBox_Artist.Location = new System.Drawing.Point(171, 78);
            this.TextBox_Artist.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TextBox_Artist.Name = "TextBox_Artist";
            this.TextBox_Artist.Size = new System.Drawing.Size(184, 23);
            this.TextBox_Artist.TabIndex = 4;

            // 
            // CheckBoxTrue
            // 
            this.CheckBoxTrue.AutoSize = true;
            this.CheckBoxTrue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.CheckBoxTrue.Location = new System.Drawing.Point(37, 147);
            this.CheckBoxTrue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CheckBoxTrue.Name = "CheckBoxTrue";
            this.CheckBoxTrue.Size = new System.Drawing.Size(256, 21);
            this.CheckBoxTrue.TabIndex = 5;
            this.CheckBoxTrue.Text = "All of the content I put above is true!";
            this.CheckBoxTrue.UseVisualStyleBackColor = true;
            this.CheckBoxTrue.CheckedChanged += new System.EventHandler(this.CB_True1_CheckedChanged);
            // 
            // ButtonSubmit
            // 
            this.ButtonSubmit.Enabled = false;
            this.ButtonSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.ButtonSubmit.Location = new System.Drawing.Point(391, 200);
            this.ButtonSubmit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ButtonSubmit.Name = "ButtonSubmit";
            this.ButtonSubmit.Size = new System.Drawing.Size(113, 41);
            this.ButtonSubmit.TabIndex = 6;
            this.ButtonSubmit.Text = "Submit";
            this.ButtonSubmit.UseVisualStyleBackColor = true;
            this.ButtonSubmit.Click += new System.EventHandler(this.Btn_Submit1_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.ButtonSubmit);
            this.Controls.Add(this.CheckBoxTrue);
            this.Controls.Add(this.TextBox_Artist);
            this.Controls.Add(this.label_Artist);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.label_Name);
            this.Controls.Add(this.ButtonNextForm);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.Text = "Main Window Form";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonNextForm;
        private System.Windows.Forms.Label label_Name;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.Label label_Artist;
        private System.Windows.Forms.TextBox TextBox_Artist;
        private System.Windows.Forms.CheckBox CheckBoxTrue;
        private System.Windows.Forms.Button ButtonSubmit;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
    }
}

